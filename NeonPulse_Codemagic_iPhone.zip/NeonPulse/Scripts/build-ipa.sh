#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodegen >/dev/null || { echo 'Install XcodeGen: brew install xcodegen'; exit 1; }
command -v xcodebuild >/dev/null || { echo 'Run on a Mac with Xcode installed'; exit 1; }
xcodegen generate
xcodebuild -project NeonPulse.xcodeproj -scheme NeonPulse -configuration Release -destination 'generic/platform=iOS' -archivePath build/NeonPulse.xcarchive archive
xcodebuild -exportArchive -archivePath build/NeonPulse.xcarchive -exportPath build/ipa -exportOptionsPlist ExportOptions.plist
printf '\nIPA output: %s\n' "$(pwd)/build/ipa"

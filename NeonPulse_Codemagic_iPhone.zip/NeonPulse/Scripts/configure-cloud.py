#!/usr/bin/env python3
"""Align XcodeGen identifiers with Codemagic's signing configuration.

Only standard-library modules are used; signing secrets are never read.
"""
from pathlib import Path
import os
import re
import sys

root = Path(__file__).resolve().parent.parent
config = (root / "codemagic.yaml").read_text(encoding="utf-8")
match = re.search(r"^\s*bundle_identifier:\s*([A-Za-z0-9_.-]+)\s*$", config, re.M)
if not match:
    sys.exit("ERROR: set ios_signing.bundle_identifier in codemagic.yaml")
bundle_id = match.group(1)
if bundle_id == "com.example.neonpulse":
    sys.exit("ERROR: replace the example bundle_identifier in codemagic.yaml with your profile's Bundle ID")
if not re.fullmatch(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", bundle_id):
    sys.exit("ERROR: invalid Bundle ID")
app_group = os.environ.get("NEON_APP_GROUP_ID", "").strip()
if not app_group.startswith("group.") or app_group == "group.com.example.neonpulse":
    sys.exit("ERROR: set NEON_APP_GROUP_ID to the App Group enabled in BOTH provisioning profiles")

project_path = root / "project.yml"
project = project_path.read_text(encoding="utf-8")
project = project.replace("com.example.neonpulse.widget", bundle_id + ".widget")
project = project.replace("com.example.neonpulse", bundle_id)
project_path.write_text(project, encoding="utf-8")

for rel in ["NeonPulse/NeonPulse.entitlements", "NeonPulseWidget/NeonPulseWidget.entitlements"]:
    path = root / rel
    contents = path.read_text(encoding="utf-8").replace("group.com.example.neonpulse", app_group)
    path.write_text(contents, encoding="utf-8")

shared = root / "Shared/TimerData.swift"
shared.write_text(shared.read_text(encoding="utf-8").replace("group.com.example.neonpulse", app_group), encoding="utf-8")
print("App bundle:", bundle_id)
print("Widget bundle:", bundle_id + ".widget")
print("App group:", app_group)

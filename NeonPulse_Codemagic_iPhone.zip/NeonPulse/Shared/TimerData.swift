import Foundation

// Set the same App Group identifier in both targets' entitlements.
enum SharedConfig {
    static let appGroup = "group.com.example.neonpulse"
    static let storageKey = "neonpulse.state.v1"
    static let defaults = UserDefaults(suiteName: appGroup) ?? .standard
}

struct HistoryEntry: Codable, Identifiable {
    enum Kind: String, Codable { case timer, stopwatch }
    let id: UUID
    let kind: Kind
    let date: Date
    let seconds: TimeInterval
    let completed: Bool
}

struct TimerSnapshot: Codable {
    var timerDuration: TimeInterval = 300
    var timerRemaining: TimeInterval = 300
    var timerEnd: Date? = nil
    var timerRunning: Bool = false
    var stopwatchElapsed: TimeInterval = 0
    var stopwatchStart: Date? = nil
    var stopwatchRunning: Bool = false
    var history: [HistoryEntry] = []

    var currentRemaining: TimeInterval {
        timerRunning ? max(0, (timerEnd ?? .now).timeIntervalSinceNow) : timerRemaining
    }
    var currentElapsed: TimeInterval {
        stopwatchElapsed + (stopwatchRunning ? Date().timeIntervalSince(stopwatchStart ?? .now) : 0)
    }
}

enum TimerStorage {
    static func read() -> TimerSnapshot {
        guard let data = SharedConfig.defaults.data(forKey: SharedConfig.storageKey),
              let value = try? JSONDecoder().decode(TimerSnapshot.self, from: data) else { return TimerSnapshot() }
        return value
    }
    static func save(_ value: TimerSnapshot) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        SharedConfig.defaults.set(data, forKey: SharedConfig.storageKey)
    }
}

func formatClock(_ seconds: TimeInterval, showTenths: Bool = false) -> String {
    let value = max(0, seconds)
    let whole = Int(value)
    let hours = whole / 3600
    let minutes = (whole % 3600) / 60
    let sec = whole % 60
    let main = hours > 0 ? String(format: "%02d:%02d:%02d", hours, minutes, sec) : String(format: "%02d:%02d", minutes, sec)
    return showTenths ? main + String(format: ".%01d", Int((value - Double(whole)) * 10)) : main
}

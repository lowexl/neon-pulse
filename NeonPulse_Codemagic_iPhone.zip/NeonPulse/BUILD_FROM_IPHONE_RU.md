# NEON PULSE — сборка .ipa только с iPhone

Этот проект содержит `codemagic.yaml` для облачной сборки iOS-приложения с WidgetKit.
Подписанный `.ipa` пока **не собран**: для него требуются совместимые сертификат и профили.

## 1. Проверьте сертификаты

- `.p12` с закрытым ключом и паролем (если установлен).
- **Два** `.mobileprovision`: для приложения и для виджета.
- Bundle ID основного приложения, например `com.company.neonpulse`.
- Bundle ID виджета — `com.company.neonpulse.widget`.
- App Group, например `group.com.company.neonpulse`, должна быть разрешена для обоих идентификаторов и присутствовать в соответствующих профилях.
- Тип профилей должен совпадать с `distribution_type`: `ad_hoc`, `development`, `app_store` или `enterprise`.
- Для Ad Hoc/Development профиль должен включать UDID iPhone; App Store-профиль предназначен для TestFlight/App Store, а не для обычной установки IPA напрямую.

Если есть только **один** `.mobileprovision`, полноценная сборка с виджетом невозможна до получения второго подходящего профиля. Не добавляйте сертификат и профиль в GitHub-репозиторий!

## 2. Подготовьте проект на iPhone

1. Откройте ZIP в приложении «Файлы» и распакуйте.
2. Создайте **приватный** репозиторий на GitHub.
3. С помощью Git-клиента для iPhone (например, Working Copy) загрузите содержимое папки `NeonPulse` в **корень** репозитория: файл `codemagic.yaml` должен быть в корне рядом с `project.yml`.
4. В `codemagic.yaml` измените ровно три значения:
   - `distribution_type` — тип ваших профилей;
   - `bundle_identifier` — Bundle ID основного приложения;
   - `NEON_APP_GROUP_ID` — точный идентификатор App Group из профилей.
   Скрипт `Scripts/configure-cloud.py` автоматически согласует остальные идентификаторы проекта.

## 3. Подключите Codemagic

1. Откройте `https://codemagic.io/` в Safari и войдите через GitHub.
2. В Codemagic: **Add application** → выберите приватный репозиторий → настройка по `codemagic.yaml`.
3. Team settings → **codemagic.yaml settings → Code signing identities**.
4. В **iOS certificates** загрузите `.p12` и введите его пароль непосредственно в Codemagic.
5. В **iOS provisioning profiles** загрузите оба `.mobileprovision`.
6. Убедитесь, что Codemagic показывает соответствие сертификата обоим профилям.
7. Запустите workflow `NEON PULSE — signed IPA` (Start new build).
8. После успешной сборки откройте **Artifacts** и скачайте `.ipa`.

## 4. Установка на iPhone

Скачанный `.ipa` можно передать в совместимый установщик, если тип подписи и профиль разрешают установку на вашем устройстве. Для Ad Hoc/Development ваш UDID должен быть в профиле; для Enterprise действуют ограничения организации. Для App Store-профиля используйте TestFlight/App Store.

## Безопасность

Не публикуйте `.p12`, `.mobileprovision`, пароль сертификата и Apple-ключи в публичных репозиториях или чатах. Загружайте их только в доверенный интерфейс управления секретами Codemagic.

## Возможные ошибки

- `No matching profiles`: не совпадает Bundle ID/тип профиля, не хватает профиля для виджета.
- `Provisioning profile doesn't include App Groups`: App Group не включена в Apple Developer или профиль устарел.
- `No signing certificate`: профиль не соответствует `.p12`, отсутствует приватный ключ или сертификат просрочен.
- `Device not registered`: UDID iPhone отсутствует в Ad Hoc/Development-профиле.

Документация: https://docs.codemagic.io/yaml-code-signing/signing-ios/

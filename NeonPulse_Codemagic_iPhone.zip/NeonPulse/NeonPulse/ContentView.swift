import SwiftUI

private enum Neon {
    static let bg = Color(red: 0.045, green: 0.025, blue: 0.11)
    static let panel = Color(red: 0.105, green: 0.075, blue: 0.20)
    static let violet = Color(red: 0.71, green: 0.43, blue: 1)
    static let cyan = Color(red: 0.23, green: 0.95, blue: 0.98)
    static let muted = Color(red: 0.64, green: 0.61, blue: 0.75)
}

struct ContentView: View {
    @EnvironmentObject private var store: TimerStore
    @State private var selected = 0

    var body: some View {
        ZStack {
            Neon.bg.ignoresSafeArea()
            RadialGradient(colors: [Neon.violet.opacity(0.18), .clear], center: .top, startRadius: 10, endRadius: 390)
                .ignoresSafeArea()
            TabView(selection: $selected) {
                TimerScreen().tabItem { Label("Таймер", systemImage: "timer") }.tag(0)
                StopwatchScreen().tabItem { Label("Секундомер", systemImage: "stopwatch") }.tag(1)
                HistoryScreen().tabItem { Label("История", systemImage: "clock.arrow.circlepath") }.tag(2)
            }
            .tint(Neon.cyan)
        }
    }
}

private struct ScreenTitle: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Image(systemName: "waveform.path")
                    .foregroundStyle(Neon.cyan)
                Text("NEON PULSE").tracking(3).foregroundStyle(Neon.cyan)
            }
            .font(.system(size: 12, weight: .bold, design: .rounded))
            Text(title).font(.system(size: 34, weight: .bold, design: .rounded)).foregroundStyle(.white)
            Text(subtitle).font(.subheadline).foregroundStyle(Neon.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 30)
    }
}

private struct NeonDial: View {
    let text: String
    let progress: Double
    let subtitle: String
    let accent: Color
    var body: some View {
        ZStack {
            Circle().stroke(accent.opacity(0.09), lineWidth: 27)
            Circle().stroke(Neon.panel, lineWidth: 13)
            Circle()
                .trim(from: 0, to: max(0, min(1, progress)))
                .stroke(AngularGradient(colors: [accent.opacity(0.4), accent, Neon.cyan], center: .center),
                        style: StrokeStyle(lineWidth: 13, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .shadow(color: accent.opacity(0.85), radius: 13)
            VStack(spacing: 10) {
                Text(text)
                    .font(.system(size: 47, weight: .light, design: .rounded))
                    .monospacedDigit().minimumScaleFactor(0.55).lineLimit(1)
                    .foregroundStyle(.white)
                Text(subtitle.uppercased()).font(.system(size: 11, weight: .semibold, design: .rounded))
                    .tracking(2).foregroundStyle(Neon.muted)
            }
            .padding(22)
        }
        .padding(24)
        .frame(maxWidth: 340)
        .accessibilityElement(children: .combine)
    }
}

private struct GlowButton: View {
    let title: String
    let symbol: String
    let primary: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Label(title, systemImage: symbol)
                .font(.system(size: 16, weight: .semibold, design: .rounded))
                .frame(maxWidth: .infinity).padding(.vertical, 17)
                .foregroundStyle(primary ? Neon.bg : Color.white)
                .background(primary ? Neon.cyan : Neon.panel, in: RoundedRectangle(cornerRadius: 17))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(primary ? Neon.cyan : Neon.violet.opacity(0.38)))
                .shadow(color: primary ? Neon.cyan.opacity(0.36) : .clear, radius: 12)
        }
        .buttonStyle(.plain)
    }
}

private struct TimerScreen: View {
    @EnvironmentObject private var store: TimerStore
    @State private var hours = 0
    @State private var minutes = 5
    @State private var seconds = 0

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 20) {
                    ScreenTitle(title: "Таймер", subtitle: "Время под твоим контролем")
                    TimelineView(.periodic(from: .now, by: 0.2)) { timeline in
                        let remaining = store.state.timerRunning
                            ? max(0, (store.state.timerEnd ?? timeline.date).timeIntervalSince(timeline.date))
                            : store.state.timerRemaining
                        NeonDial(text: formatClock(remaining),
                                 progress: store.state.timerDuration > 0 ? remaining / store.state.timerDuration : 0,
                                 subtitle: store.state.timerRunning ? "ИДЁТ ОТСЧЁТ" : remaining == 0 ? "ЗАВЕРШЕНО" : "ГОТОВ К СТАРТУ",
                                 accent: Neon.violet)
                            .frame(maxWidth: .infinity)
                            .onChange(of: remaining <= 0 && store.state.timerRunning) { ended in
                                if ended { store.reconcileFinishedTimer() }
                            }
                    }
                    HStack(spacing: 10) {
                        durationInput("ЧАСЫ", value: $hours, range: 0...23)
                        durationInput("МИН", value: $minutes, range: 0...59)
                        durationInput("СЕК", value: $seconds, range: 0...59)
                    }
                    .disabled(store.state.timerRunning)
                    .opacity(store.state.timerRunning ? 0.45 : 1)
                    HStack(spacing: 12) {
                        GlowButton(title: "Сброс", symbol: "arrow.counterclockwise", primary: false) {
                            store.resetTimer()
                        }
                        GlowButton(title: store.state.timerRunning ? "Пауза" : "Старт",
                                   symbol: store.state.timerRunning ? "pause.fill" : "play.fill", primary: true) {
                            if store.state.timerRunning { store.pauseTimer() }
                            else { store.startTimer() }
                        }
                    }
                    if !store.notificationsGranted {
                        Button {
                            store.requestNotificationPermission()
                        } label: {
                            Label("Разрешить уведомления для сигнала при блокировке", systemImage: "bell.badge")
                                .font(.footnote).foregroundStyle(Neon.cyan)
                        }
                        .padding(.top, 4)
                    }
                }
                .padding(.horizontal, 24)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
        .onAppear(perform: syncInputs)
        .onChange(of: hours) { _ in updateDuration() }
        .onChange(of: minutes) { _ in updateDuration() }
        .onChange(of: seconds) { _ in updateDuration() }
    }

    private func durationInput(_ label: String, value: Binding<Int>, range: ClosedRange<Int>) -> some View {
        VStack(spacing: 9) {
            Text(label).font(.system(size: 10, weight: .bold)).tracking(1.3).foregroundStyle(Neon.muted)
            Picker(label, selection: value) {
                ForEach(range, id: \.self) { n in Text(String(format: "%02d", n)).tag(n) }
            }
            .pickerStyle(.wheel)
            .frame(height: 92)
            .clipped()
            .colorScheme(.dark)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 6)
        .background(Neon.panel, in: RoundedRectangle(cornerRadius: 17))
    }

    private func syncInputs() {
        let duration = Int(store.state.timerDuration)
        hours = duration / 3600
        minutes = (duration % 3600) / 60
        seconds = duration % 60
    }

    private func updateDuration() {
        guard !store.state.timerRunning else { return }
        let total = TimeInterval(hours * 3600 + minutes * 60 + seconds)
        if total > 0, total != store.state.timerDuration { store.setDuration(total) }
    }
}

private struct StopwatchScreen: View {
    @EnvironmentObject private var store: TimerStore
    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 25) {
                    ScreenTitle(title: "Секундомер", subtitle: "Каждая доля секунды важна")
                    TimelineView(.periodic(from: .now, by: 0.1)) { timeline in
                        let elapsed = store.state.stopwatchElapsed + (store.state.stopwatchRunning
                           ? max(0, timeline.date.timeIntervalSince(store.state.stopwatchStart ?? timeline.date)) : 0)
                        NeonDial(text: formatClock(elapsed, showTenths: true),
                                 progress: (elapsed.truncatingRemainder(dividingBy: 60)) / 60,
                                 subtitle: store.state.stopwatchRunning ? "ИЗМЕРЕНИЕ" : "ОЖИДАНИЕ",
                                 accent: Neon.cyan)
                            .frame(maxWidth: .infinity)
                    }
                    HStack(spacing: 12) {
                        GlowButton(title: "Сохранить", symbol: "checkmark", primary: false) {
                            store.finishStopwatch()
                        }
                        GlowButton(title: store.state.stopwatchRunning ? "Пауза" : "Старт",
                                   symbol: store.state.stopwatchRunning ? "pause.fill" : "play.fill", primary: true) {
                            if store.state.stopwatchRunning { store.pauseStopwatch() }
                            else { store.startStopwatch() }
                        }
                    }
                    Text("Останови и сохрани результат в истории")
                        .font(.footnote).foregroundStyle(Neon.muted)
                }
                .padding(.horizontal, 24)
                .frame(minHeight: geometry.size.height, alignment: .top)
            }
        }
    }
}

private struct HistoryScreen: View {
    @EnvironmentObject private var store: TimerStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    ScreenTitle(title: "История", subtitle: "Твои последние измерения")
                    if store.state.history.isEmpty {
                        VStack(spacing: 12) {
                            Image(systemName: "clock.arrow.circlepath").font(.system(size: 44)).foregroundStyle(Neon.violet)
                            Text("Пока нет записей").font(.headline)
                            Text("Заверши таймер или сохрани секундомер")
                                .font(.subheadline).foregroundStyle(Neon.muted)
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 90)
                    } else {
                        ForEach(store.state.history) { entry in
                            HStack(spacing: 14) {
                                Image(systemName: entry.kind == .timer ? "timer" : "stopwatch")
                                    .foregroundStyle(entry.kind == .timer ? Neon.violet : Neon.cyan)
                                    .font(.title3).frame(width: 34)
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(entry.kind == .timer ? "Таймер завершён" : "Секундомер")
                                        .font(.subheadline.bold())
                                    Text(entry.date, format: .dateTime.day().month().year().hour().minute())
                                        .font(.caption).foregroundStyle(Neon.muted)
                                }
                                Spacer()
                                Text(formatClock(entry.seconds, showTenths: entry.kind == .stopwatch))
                                    .font(.system(.subheadline, design: .monospaced).bold())
                                    .foregroundStyle(.white)
                            }
                            .padding(16)
                            .background(Neon.panel, in: RoundedRectangle(cornerRadius: 16))
                        }
                    }
                }
                .padding(.horizontal, 24)
            }
            .background(Neon.bg)
            .toolbar {
                if !store.state.history.isEmpty {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Очистить", role: .destructive) { store.clearHistory() }
                            .foregroundStyle(Neon.cyan)
                    }
                }
            }
        }
    }
}

import Foundation
import SwiftUI
import UserNotifications
import WidgetKit
import AudioToolbox

@MainActor
final class TimerStore: ObservableObject {
    @Published private(set) var state: TimerSnapshot
    @Published var notificationsGranted = false
    private let notificationID = "neonpulse.timer.finished"

    init() {
        state = TimerStorage.read()
        reconcileFinishedTimer()
        Task { await checkPermission() }
    }

    func persist() {
        TimerStorage.save(state)
        WidgetCenter.shared.reloadAllTimelines()
    }

    func checkPermission() async {
        let settings = await UNUserNotificationCenter.current().notificationSettings()
        notificationsGranted = settings.authorizationStatus == .authorized || settings.authorizationStatus == .provisional
    }

    func requestNotificationPermission() {
        Task {
            let granted = (try? await UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge])) ?? false
            notificationsGranted = granted
        }
    }

    func setDuration(_ duration: TimeInterval) {
        guard !state.timerRunning else { return }
        state.timerDuration = max(1, duration)
        state.timerRemaining = state.timerDuration
        persist()
    }

    func startTimer() {
        guard !state.timerRunning, state.timerRemaining > 0 else { return }
        state.timerEnd = Date().addingTimeInterval(state.timerRemaining)
        state.timerRunning = true
        persist()
        scheduleAlarm()
    }

    func pauseTimer() {
        guard state.timerRunning else { return }
        state.timerRemaining = state.currentRemaining
        state.timerEnd = nil
        state.timerRunning = false
        cancelAlarm()
        persist()
    }

    func resetTimer() {
        cancelAlarm()
        state.timerRunning = false
        state.timerEnd = nil
        state.timerRemaining = state.timerDuration
        persist()
    }

    // Called on foreground activation and when the countdown on screen reaches zero.
    func reconcileFinishedTimer() {
        guard state.timerRunning, state.currentRemaining <= 0 else { return }
        let finishDate = state.timerEnd ?? Date()
        state.history.insert(HistoryEntry(id: UUID(), kind: .timer, date: finishDate,
                                          seconds: state.timerDuration, completed: true), at: 0)
        trimHistory()
        state.timerRunning = false
        state.timerRemaining = 0
        state.timerEnd = nil
        persist()
        if UIApplication.shared.applicationState == .active {
            AudioServicesPlaySystemSound(1005)
        }
    }

    func startStopwatch() {
        guard !state.stopwatchRunning else { return }
        state.stopwatchStart = .now
        state.stopwatchRunning = true
        persist()
    }

    func pauseStopwatch() {
        guard state.stopwatchRunning else { return }
        state.stopwatchElapsed = state.currentElapsed
        state.stopwatchStart = nil
        state.stopwatchRunning = false
        persist()
    }

    func finishStopwatch() {
        let elapsed = state.currentElapsed
        if elapsed >= 0.1 {
            state.history.insert(HistoryEntry(id: UUID(), kind: .stopwatch, date: .now,
                                              seconds: elapsed, completed: true), at: 0)
        }
        state.stopwatchElapsed = 0
        state.stopwatchStart = nil
        state.stopwatchRunning = false
        trimHistory()
        persist()
    }

    func clearHistory() {
        state.history.removeAll()
        persist()
    }

    private func trimHistory() { state.history = Array(state.history.prefix(200)) }

    private func scheduleAlarm() {
        cancelAlarm()
        guard let end = state.timerEnd else { return }
        let content = UNMutableNotificationContent()
        content.title = "NEON PULSE"
        content.body = "Время вышло! Таймер завершён."
        content.sound = .default
        let interval = max(1, end.timeIntervalSinceNow)
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)
        UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: notificationID, content: content, trigger: trigger))
    }

    private func cancelAlarm() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [notificationID])
        UNUserNotificationCenter.current().removeDeliveredNotifications(withIdentifiers: [notificationID])
    }
}

import SwiftUI
import UserNotifications

@main
struct NeonPulseApp: App {
    @StateObject private var store = TimerStore()
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(.dark)
                .onChange(of: phase) { newPhase in
                    if newPhase == .active { store.reconcileFinishedTimer() }
                }
        }
    }
}

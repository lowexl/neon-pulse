import SwiftUI
import WidgetKit

private struct PulseEntry: TimelineEntry {
    let date: Date
    let snapshot: TimerSnapshot
}

private struct PulseProvider: TimelineProvider {
    func placeholder(in context: Context) -> PulseEntry { PulseEntry(date: .now, snapshot: TimerSnapshot()) }
    func getSnapshot(in context: Context, completion: @escaping (PulseEntry) -> Void) {
        completion(PulseEntry(date: .now, snapshot: TimerStorage.read()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<PulseEntry>) -> Void) {
        let snapshot = TimerStorage.read()
        let now = Date()
        // Dynamic timer text updates continuously via the OS, even without a new timeline entry.
        let refresh = snapshot.timerRunning ? max(now.addingTimeInterval(60), snapshot.timerEnd ?? now) : now.addingTimeInterval(900)
        completion(Timeline(entries: [PulseEntry(date: now, snapshot: snapshot)], policy: .after(refresh)))
    }
}

private struct PulseWidgetView: View {
    let entry: PulseEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 6) {
                Image(systemName: "waveform.path")
                Text("NEON PULSE").tracking(1.4)
            }
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(Color(red: 0.26, green: 0.96, blue: 0.98))
            Spacer(minLength: 0)
            if entry.snapshot.timerRunning, let end = entry.snapshot.timerEnd, end > entry.date {
                Text(end, style: .timer)
                    .font(.system(size: 29, weight: .medium, design: .rounded))
                    .monospacedDigit()
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
                    .foregroundStyle(.white)
                Text("ТАЙМЕР ИДЁТ").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.65))
            } else if entry.snapshot.timerRunning, (entry.snapshot.timerEnd ?? entry.date) <= entry.date {
                Text("00:00")
                    .font(.system(size: 29, weight: .medium, design: .rounded))
                    .foregroundStyle(.white)
                Text("ВРЕМЯ ВЫШЛО").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.65))
            } else if entry.snapshot.stopwatchRunning, let start = entry.snapshot.stopwatchStart {
                Text(start.addingTimeInterval(-entry.snapshot.stopwatchElapsed), style: .timer)
                    .font(.system(size: 29, weight: .medium, design: .rounded))
                    .monospacedDigit()
                    .minimumScaleFactor(0.6)
                    .lineLimit(1)
                    .foregroundStyle(.white)
                Text("СЕКУНДОМЕР ИДЁТ").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.65))
            } else {
                Text(formatClock(entry.snapshot.timerRemaining))
                    .font(.system(size: 29, weight: .medium, design: .rounded))
                    .monospacedDigit().foregroundStyle(.white)
                Text("ГОТОВ К СТАРТУ").font(.system(size: 10, weight: .bold)).foregroundStyle(.white.opacity(0.65))
            }
        }
        .padding(3)
        .containerBackground(for: .widget) {
            LinearGradient(colors: [Color(red: 0.13, green: 0.08, blue: 0.28),
                                    Color(red: 0.035, green: 0.02, blue: 0.09)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
        }
        .widgetURL(URL(string: "neonpulse://home"))
    }
}

struct NeonPulseWidget: Widget {
    let kind: String = "NeonPulseWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: PulseProvider()) { entry in
            PulseWidgetView(entry: entry)
        }
        .configurationDisplayName("Neon Pulse")
        .description("Таймер и секундомер на главном экране")
        .supportedFamilies([.systemSmall, .systemMedium])
    }
}

@main
struct NeonPulseWidgetBundle: WidgetBundle {
    var body: some Widget { NeonPulseWidget() }
}
